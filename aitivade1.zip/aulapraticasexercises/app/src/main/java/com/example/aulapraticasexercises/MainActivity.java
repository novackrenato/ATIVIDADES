package com.example.aulapraticasexercises;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        texto1 = (EditText)findViewById(R.id.txt1);
        texto2 = (EditText)findViewById(R.id.txt2);
        texto3 = (EditText)findViewById(R.id.dividir);
        texto1.getText().toString();
        texto2.getText().toString();
        texto3.getText().toString();

        calcular.setOnclickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                total = texto1+texto2;
                taxa = total - 10 / 100;
                result = total / texto3;

                total.getText().toString();

            }
        });
    }

}
